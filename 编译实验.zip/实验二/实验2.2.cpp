#include<iostream>
#include<string>
#include<stdio.h>
using namespace std;

string s;
int p=0;
int flag=1;

int match(char ch); 
void error();
int E(int a);
int E2(int a);
int T(int a);
int T2(int a);
int F(int a);

int match(char ch){
	if(s[p]==ch){
		cout<<s[p]<<"\n";
		p++; return 1;
	}else{
		return 0;
	}   
}

void error(){
	cout<<"����ʧ�ܣ�����ı���ʽ���Ϸ�\n"; 
}

int E(int a){
	int num;
	//num =a;
	num=T(a);
	num=E2(num);
	return num;
}

int E2(int a){     //�ɿ� 
	int num;
	num =a;
	 if (match('+')){
	 	
	 	
	 	 num+=T(0);
	 	 num=E2(num);
	 }else if(match('-')){
	 	
	 	 num+=T(0);
	 	 num=E2(num);
	 }
	 return num;
}

int T(int a){
	int num;
	
	num = F(0);
	num=T2(num); 
	
	return num;
}

int T2(int a){     //�ɿ� 
	int num;
	num=a;
	
	if (match('*')){
		
	 	num*=F(0);
	 	num=T2(num);
	}else if(match('/')){
		
	 	num/=F(0);
	 	T2(num);
	}
	
	return num;
}

int F(int a){
	int num=a;
	
	if(s[p]>=48&&s[p]<=57){
		//cout<<s[p]<<"\n";
		num=a+s[p]-48;
		p++;
		 
		if(s[p]>=48&&s[p]<=57){
			num*=10;
			num=F(num);
			
		}else{
			cout<<num<<"\n";
			
		}	
	}else if(s[p]=='('){
		//cout<<s[p]<<"\n";
		cout<<"(\n";
		p++;
		num=E(a);
		if(s[p]==')'){
			//cout<<s[p]<<"\n";
			p++;
		}else{
			flag=0;
		}
		cout<<")\n";
	}else{
	
		flag=0;
	}
	
	//cout<<num<<"\n";
	return num;
	
}
int main()
{
	freopen("in2.txt","r",stdin);
	cin>>s;
	cout<<s<<"\n";
	E(0);
	//cout<<p<<"\n";
	if(s[p]=='#'&&flag==1){   //��s��#ǰ���޷�ʶ��ķ� ���в������ķ��� �� ����� 
		p=0; 
		cout<<"�����ɹ�"<<E(0)<<"\n"; 
		
	}else{
		error();
	}
	return 0;
} 
